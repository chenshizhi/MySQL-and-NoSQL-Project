create table [CHANCE]
(ID int PRIMARY KEY,
 Name varchar(50),
 [Description] varchar(255),
 Times_Used int
);
create table [CORNERS]
(ID int PRIMARY KEY,
 Name varchar(50),
 [Description] varchar(255)
);
create table [PLAYER]
(ID int PRIMARY KEY,
 Name varchar(50),
 Token varchar(50),
 C_Location varchar(50),
 Balance int,
 No_Properties int,
 Age smallint,
 Still_in_Jail smallint
);
create table [TOKEN]
(Name varchar(50) PRIMARY KEY,
 Selected bit,
 ID int
);
create table [PLAYER_TOKEN]
(ID int,
 Name varchar(50),
 RoundNum int,
 foreign key([ID]) references [PLAYER](ID),
 foreign key([Name]) references [TOKEN](Name)
);
create table [STREETS]
(
 Name varchar(50) PRIMARY KEY,
 Cost int,
 [Owner] int,
 Colour varchar(50)
 foreign key([Owner]) references [PLAYER](ID),
);
insert into PLAYER values(1,'Mary','Battleship','Free Parking',90,2,23,0)
insert into PLAYER values(2,'Bill','Dog','Sackville',110,3,31,0)
insert into PLAYER values(3,'Jane','Car','Waterloo',50,0,17,0)
insert into PLAYER values(4,'Norman','Tophat','GO!',130,1,25,0)

insert into TOKEN values('Dog',1,2)
insert into TOKEN values('Tophat',1,4)
insert into TOKEN values('Battleship',1,1)
insert into TOKEN(Name,Selected) values('Iron',0)
insert into TOKEN values('Car',1,3)

insert into PLAYER_TOKEN values(2,'Dog',0)
insert into PLAYER_TOKEN values(4,'Tophat',0)
insert into PLAYER_TOKEN values(1,'Battleship',0)
insert into PLAYER_TOKEN values(3,'Car',0)

insert into STREETS values('Kilburn',10,1,'Yellow')
insert into STREETS values('Waterloo',10,2,'Yellow')
insert into STREETS values('Roscoe',20,1,'Green')
insert into STREETS values('Opal Hall',20,2,'Green')
insert into STREETS values('Ronson Hall',30,2,'Red')
insert into STREETS(Name,Cost,Colour) values('Sudgen Sports',30,'Red')
insert into STREETS values('Sackville',40,4,'Blue')
insert into STREETS(Name,Cost,Colour) values('Alan Turing',40,'Blue')

insert into CORNERS values(1,'GO!','Collect 20')
insert into CORNERS values(2,'Jail','Nothing happens unless in Jain then must roll 6')
insert into CORNERS values(3,'Free Parking','Nothing happens')
insert into CORNERS values(4,'Go To Jail','Go To Jail')

insert into CHANCE values(1,'Dance Competition','You win a dance competition, collect 20',0)
insert into CHANCE values(2,'Council Tax','You must pay your taxes, loose 30',0)
insert into CHANCE values(3,'Free Move','Move forwardss 3 spaces',0)