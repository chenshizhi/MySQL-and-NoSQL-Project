create view display_state_of_the_players(Round_Num,Player_ID,Player_Name,Current_Balance,No_Properties,[Space])
as
select PLAYER_TOKEN.RoundNum, PLAYER.ID, PLAYER.Name,PLAYER.Balance, PLAYER.No_Properties, PLAYER.C_Location
from PLAYER,PLAYER_TOKEN
where PLAYER.ID=PLAYER_TOKEN.ID