create table [CHANCE]
(ID int PRIMARY KEY,
 Name varchar(50),
 [Description] varchar(255),
 Times_Used int
);
create table [CORNERS]
(ID int PRIMARY KEY,
 Name varchar(50),
 [Description] varchar(255)
);
create table [PLAYER]
(ID int PRIMARY KEY,
 Name varchar(50),
 Token varchar(50),
 C_Location varchar(50),
 Balance int,
 No_Properties int,
 Age smallint
);
create table [TOKEN]
(Name varchar(50) PRIMARY KEY,
 Selected bit,
 ID int
);
create table [PLAYER_TOKEN]
(ID int,
 Name varchar(50),
 RoundNum int,
 foreign key([ID]) references [PLAYER](ID),
 foreign key([Name]) references [TOKEN](Name)
);
create table [STREETS]
(
 Name varchar(50) PRIMARY KEY,
 Cost int,
 [Owner] int,
 Colour varchar(50)
 foreign key([Owner]) references [PLAYER](ID),
);
create table [MAP]
(
 ID int,
 Name varchar(50)
);
create table [CHANCE_ORDER]
(
 ID int,
 [Order] smallint
);