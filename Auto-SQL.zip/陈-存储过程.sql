create procedure Game_Run 
@Player_Name varchar(50),@Roll smallint,@RN int/*Player_Name is player'name, Roll is the number of the player rolls*/
as
begin 
	declare
	@Current_MAP_ID int,/*player's current ID of the map*/
	@Current_MAP_Name varchar(50),/*player's location's name*/
	@Next_Location_MAP_ID int,/*player's next location's ID of the map*/
	@Next_Location_MAP_Name varchar(50),/*player's next location's name of the map*/
	@Street_Cost int,/*cost of the street that the player steps in*/
	@Street_Owner int,/*owner of the street*/
	@Current_Chance_Order smallint,/*current ordet of the chance being choosed*/
	@Current_Chance_ID int,/*current ID of the chance being choosed*/
	@MoveForward3Steps_MAP_Name varchar(50),/*name of the location after the player moves 3 steps forward*/
	@Player_ID int;/*ID of the player*/
	
	set @Current_MAP_ID=(select MAP.ID from MAP where MAP.Name =(select C_Location from PLAYER where @Player_Name=PLAYER.Name))
	set @Current_MAP_Name=(select MAP.Name from MAP where MAP.ID =@Current_MAP_ID)
	print('Current_MAP_Name:');
	print(@Current_MAP_Name);
	
	if(select PLAYER.Still_in_Jail from PLAYER where @Player_Name=PLAYER.Name)=0 or (select PLAYER.Still_in_Jail from PLAYER where @Player_Name=PLAYER.Name)=2
	begin
		print('Just go!')
	end;
	else
	begin
		if @Current_MAP_Name='JAIL' and @Roll!=6/*the player is in jail and doesn't roll 6, so can't move*/
		begin
			print('You can not move!Cause you are in jail and have to roll 6 to leave!')
			return	
		end;		
		if @Current_MAP_Name='JAIL' and @Roll=6 and (select PLAYER.Still_in_Jail from PLAYER where @Player_Name=PLAYER.Name)=1/*the player could leave jail*/
		begin
			update PLAYER set Still_in_Jail=2 where @Player_Name=PLAYER.Name
			print('You are allowed to leave jail!')
			return
		end;
	end;
	
	set @Next_Location_MAP_ID=(select MAP.ID from MAP where MAP.ID =(@Current_MAP_ID+@Roll)%16);/*be careful with the num 16*/
	print('Next_Location_MAP_ID:');
	print(@Next_Location_MAP_ID);
	set @Next_Location_MAP_Name=(select MAP.Name from MAP where MAP.ID=@Next_Location_MAP_ID);	
	print('Next_Location_MAP_Name:');
	print(@Next_Location_MAP_Name);
	
	set @Street_Cost=(select STREETS.Cost from STREETS where @Next_Location_MAP_Name=STREETS.Name);
	
	set @Street_Owner=(select STREETS.[Owner] from STREETS where @Next_Location_MAP_Name=STREETS.Name);
	
	set @Current_Chance_Order=(select SUM(CHANCE.Times_Used)from CHANCE );/*compute the total num of the chance that has been used to determine the order of chances*/
	
	set @Current_Chance_ID=(select CHANCE_ORDER.Chance_Num from CHANCE_ORDER where @Current_Chance_Order=CHANCE_ORDER.ID);
	
	set @MoveForward3Steps_MAP_Name=(select MAP.Name from MAP where MAP.ID=(@Next_Location_MAP_ID+3)%16);/*be careful with the num 16*/
	
	set @Player_ID=(select PLAYER.ID from PLAYER where PLAYER.Name=@Player_Name);
	
	update PLAYER_TOKEN set RoundNum=@RN where ID=@Player_ID;
	update PLAYER set C_Location=@Next_Location_MAP_Name where PLAYER.Name=@Player_Name;

	if @Current_MAP_ID+@Roll>15/*the player passes the corner GO!*/
	begin
		print('You happen to pass the GO!')
		update PLAYER set Balance=Balance+20 where PLAYER.Name=@Player_Name
	end
	if @Next_Location_MAP_ID%2!=0 /*the player enters into the streets*/
	begin
		print('You are in the street!');	
		if @Street_Owner is null/*street is still not being bought, so the player has to buy it*/
		begin
			if (select Balance from PLAYER where PLAYER.Name=@Player_Name)<	@Street_Cost/*the player has not enough money to buy the street*/
				print('You have not enough balance to buy the street!')			
			else
			begin
				update STREETS set STREETS.[Owner]=@Player_ID where STREETS.Name=@Next_Location_MAP_Name
				update PLAYER set No_Properties=No_Properties+1,Balance=Balance-@Street_Cost where PLAYER.Name=@Player_Name
			end;
		end;
		else
		begin
			if (select Balance from PLAYER where PLAYER.Name=@Player_Name)<	@Street_Cost/*street has been bought so the player has to pay for it*/
				print('You have not enough balance to pay for the rent! You are broke!')
			else
			begin
				update PLAYER set Balance=Balance-@Street_Cost where PLAYER.Name=@Player_Name
				update PLAYER set Balance=Balance+@Street_Cost where PLAYER.ID=@Street_Owner
			end
		end;
	end;
	else if @Next_Location_MAP_ID=2 or @Next_Location_MAP_ID=6 or @Next_Location_MAP_ID=10 or @Next_Location_MAP_ID=14/*the player enters into the chance*/
	begin
		print('You are in the chances!');
		if @Current_Chance_ID=1/*CHANE=1,that is Dance Competition*/
		begin
			print('You have the CHANCE Dance Competition!');
			update PLAYER set Balance=Balance+20 where PLAYER.Name=@Player_Name
			update CHANCE set Times_Used=Times_Used+1 where CHANCE.ID=1
		end;
		else if @Current_Chance_ID=2/*CHANE=2,that is Councial Tax*/
		begin
			print('You have the CHANCE Councial Tax!');
			update PLAYER set Balance=Balance-30 where PLAYER.Name=@Player_Name
			update CHANCE set Times_Used=Times_Used+1 where CHANCE.ID=2
		end;
		else/*CHANE=3,that is Free Move.Noth that when moving forward 3 steps the player must enter into the street, then repeat the same process as above*/
		begin
			print('You have the CHANCE Free Move!');
			update PLAYER set PLAYER.C_Location=@MoveForward3Steps_MAP_Name where PLAYER.Name=@Player_Name
			update CHANCE set Times_Used=Times_Used+1 where CHANCE.ID=3
			
			set @Street_Owner=(select STREETS.[Owner] from STREETS,PLAYER where PLAYER.Name=@Player_Name and PLAYER.C_Location=STREETS.Name)/*owner of the street has changed*/
			set @Street_Cost=(select STREETS.Cost from STREETS where @MoveForward3Steps_MAP_Name=STREETS.Name);/*cost of the street has changed*/
			
			if @Street_Owner is null
			begin
				if (select Balance from PLAYER where PLAYER.Name=@Player_Name)<	@Street_Cost
					print('You have not enough balance to buy the street!')			
				else
				begin
					update STREETS set STREETS.[Owner]=@Player_ID where STREETS.Name=@MoveForward3Steps_MAP_Name
					update PLAYER set No_Properties=No_Properties+1,Balance=Balance-@Street_Cost where PLAYER.Name=@Player_Name
				end;
			end;
			else
			begin
				if (select Balance from PLAYER where PLAYER.Name=@Player_Name)<	@Street_Cost/*street has been bought so the player has to pay for it*/
					print('You have not enough balance to pay for the rent! You are broke!')
				else
				begin
					update PLAYER set Balance=Balance-@Street_Cost where PLAYER.Name=@Player_Name
					update PLAYER set Balance=Balance+@Street_Cost where PLAYER.ID=@Street_Owner
				end
			end;
		end;
	end;
	else/*the player enters into the corners*/
	begin
		if	@Next_Location_MAP_Name='GO!'
		begin
			print('You are collecting 20$ for passing the CORNER GO!')
			update PLAYER set Balance=Balance+20 where PLAYER.Name=@Player_Name
		end;
		else if @Next_Location_MAP_Name='FREE PARKING' or @Next_Location_MAP_Name='JAIL'
			print('You are in the FREE PARKING or JAIL!')
		else
		begin
			print('You are going to jail!')
			update PLAYER set C_Location='JAIL' where PLAYER.Name=@Player_Name
			update PLAYER set Still_in_Jail=1 where PLAYER.Name=@Player_Name
		end
	end;
end;