exec Game_Run 'Jane',3,1
exec Game_Run 'Norman',1,1
exec Game_Run 'Mary',4,1
exec Game_Run 'Bill',2,1

exec Game_Run 'Jane',4,2
exec Game_Run 'Norman',4,2
exec Game_Run 'Mary',5,2
exec Game_Run 'Bill',6,2
exec Game_Run 'Bill',1,2

exec Game_Run 'Jane',4,3
exec Game_Run 'Norman',5,3
exec Game_Run 'Mary',6,3
exec Game_Run 'Mary',1,3
exec Game_Run 'Bill',6,3
exec Game_Run 'Bill',1,3